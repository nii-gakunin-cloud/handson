#!/bin/bash
#SBATCH -N 1
#SBATCH -n 1

srun pip3 install --user numpy
